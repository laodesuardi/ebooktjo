<?php $__env->startComponent('mail::message'); ?>
# Ebook Tembus Target Jualan Online

Terima kasih sudah memasukan data, tunggu beberapa saat, link download akan dikirim ke nomor whatsapp anda....

Apabila anda belum menerima link download, klik tombol dibawah ini.
<?php $__env->startComponent('mail::button', ['url' => 'https://bit.ly/3cII0tx']); ?>
Kirim pesan
<?php echo $__env->renderComponent(); ?>

Terima kasih,<br>
<?php echo e(config('app.nama')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\aplications\lead\resources\views/emails/email.blade.php ENDPATH**/ ?>